/**
 * @license Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see https://ckeditor.com/legal/ckeditor-oss-license
 */

CKEDITOR.editorConfig = function( config ) {
	// Define changes to default configuration here. For example:
	// config.language = 'fr';
	// config.uiColor = '#AADC6E';
	// config.image_previewText = '';
    // config.removeDialogTabs = 'image:advanced;image:Link';//隐藏超链接与高级选项
    // config.filebrowserImageUploadUrl = "http://localhost:8888/moon-web/hello/upload";//上传图片的地址
};
